#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <limits.h>

#define LED0 "/sys/class/leds/beaglebone:green:usr0/brightness"
#define LED1 "/sys/class/leds/beaglebone:green:usr1/brightness"
#define LED2 "/sys/class/leds/beaglebone:green:usr2/brightness"
#define LED3 "/sys/class/leds/beaglebone:green:usr3/brightness"
#define BUTTON "/sys/class/gpio/gpio72/value"

static long long getTimeInMs(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC_RAW, &ts);
    return ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
}

static void sleepForMs(long long delayInMs) {
    const long long NS_PER_MS = 1000 * 1000;
    const long long NS_PER_SECOND = 1000000000;
    long long delayNs = delayInMs * NS_PER_MS;
    int seconds = delayNs / NS_PER_SECOND;
    int nanoseconds = delayNs % NS_PER_SECOND;
    struct timespec reqDelay = {seconds, nanoseconds};
    nanosleep(&reqDelay, (struct timespec *) NULL);
}

static void runCommand(char* command) {
    FILE *pipe = popen(command, "r");
    char buffer[1024];
    while (!feof(pipe) && !ferror(pipe)) {
        if (fgets(buffer, sizeof(buffer), pipe) == NULL) break;
    }
    int exitCode = WEXITSTATUS(pclose(pipe));
    if (exitCode != 0) {
        perror("Unable to execute command:");
        printf(" command: %s\n", command);
        printf(" exit code: %d\n", exitCode);
    }
}

//active LED
static void setLED(char* ledPath, int state) {
    char command[256];
    snprintf(command, sizeof(command), "echo %d > %s", state, ledPath);//ie: echo 1 to path led0
    runCommand(command);
}

//active BUTTON
static int readButton(void) {
    char command[256];
    snprintf(command, sizeof(command), "cat %s", BUTTON);
    FILE *pipe = popen(command, "r");
    char buffer[10];
    if (!feof(pipe) && !ferror(pipe)) {
        if (fgets(buffer, sizeof(buffer), pipe) == NULL) 
            return 0;
    }
    pclose(pipe);
    return atoi(buffer);
}

int main(void) {
    printf("Hello embedded world, from Tom!\n");
    printf("\n");
    //config button
    runCommand("config-pin p8.43 gpio");
    //store the best time
    long long bestResponseTime = 5000;
    printf("When LED3 lights up, press the USER button!\n");
    while (1) {

        //printf ("Button value: %d\n", readButton());
        // . Wait while user holds down USER button
        while (readButton() == 0) sleepForMs(10);

 
        //2. Light only LED 0
        setLED(LED0, 1);
        setLED(LED1, 0);
        setLED(LED2, 0);
        setLED(LED3, 0);

        //3. Wait a random time (between 0.5s and 3.0s)
        srand(time(NULL));
        int randomTime = 500 + rand() % 2501;
        //sleepForMs(randomTime);
        
        int elapsedSleep = 0;

        while (elapsedSleep < randomTime) {
            if (readButton() == 0) {
            // Go to the early response handling code below
                goto early_response;
            }
            sleepForMs(10);
            elapsedSleep += 10;
        }  
        
        early_response:
        //4. If user is pressing the USER button already
        if (readButton() == 0) {
          

            printf("Too early! Press when LED3 light!\n");                    
            
            setLED(LED0, 1);
            setLED(LED1, 1);
            setLED(LED2, 1);
            setLED(LED3, 1);
            continue;
        }

        //5. Light up LED 3 & start timer
        setLED(LED0, 0);
        setLED(LED3, 1);
        long long startTime = getTimeInMs();

    
        //6. When user presses USER button, stop timer
        
        while (readButton() == 1) {
            if (getTimeInMs() - startTime > 5000) {
                // If timer > 5s, exit with a message without waiting for button press
                printf("No input within 5000ms; quitting! \n");
                printf("Best response time: %lldms.\n", bestResponseTime);
                // Light up all LEDs
                setLED(LED0, 1);
                setLED(LED1, 1);
                setLED(LED2, 1);
                setLED(LED3, 1);
                return 0;
            }
            sleepForMs(10);
        }

        long long time = getTimeInMs() - startTime;
         if (time < bestResponseTime){
            bestResponseTime = time;
            printf("New best time!\n");
        }
        printf("Your recation time was %lldms; best so far in game is %lldms.\n", time,bestResponseTime);
        //printf("Response time: %lld ms\n", time);    
        if (time < bestResponseTime){
            bestResponseTime = time;
        }
        //7. Light up all LEDs
        setLED(LED0, 1);
        setLED(LED1, 1);
        setLED(LED2, 1);
        setLED(LED3, 1);

        
    }

    
/*
 int prevButtonState = 0; // Assume button is initially not pressed
runCommand("config-pin p8.43 gpio");
while (1) {
    int currentButtonState = readButton();

    // Detecting the press edge
    if (currentButtonState == 1 && prevButtonState == 0) {
        printf("Button was just pressed!\n");
    }

    // Update the previous state for the next loop iteration
    prevButtonState = currentButtonState;

    sleepForMs(10); // Sleep a short time to prevent excessive CPU usage
}
*/
  return 0;
}

